import{w as a}from"./DTK62OxW.js";const s=a(!1),t=a("email"),c=a("#0a0908");export{c,s as m,t as w};

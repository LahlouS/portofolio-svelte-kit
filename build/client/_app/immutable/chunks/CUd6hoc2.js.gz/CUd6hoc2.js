const t="https://dev.to/api/articles",s="https://dev.to/api/articles?username=",a="lahlousacha@gmail.com",o="+33 6 68 83 26 54";export{t as A,a as E,o as P,s as U};
